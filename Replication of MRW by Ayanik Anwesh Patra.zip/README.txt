Mankiw Romer Weil Paper Replication

I have used the all the data from Penn World Table --version 10 for replication and extention of the study. The data on employment and gdp are 
in million terms adjusted to 2017 US million Dollar prices. 